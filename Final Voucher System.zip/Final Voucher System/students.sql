-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2014 at 06:49 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `voucherdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `studentinformation`
--

CREATE TABLE IF NOT EXISTS `studentinformation` (
`idNum` int(10) NOT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `Amount` double NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10216 ;

--
-- Dumping data for table `studentinformation`
--

INSERT INTO `studentinformation` (`idNum`, `firstName`, `lastName`, `department`, `gender`, `username`, `password`, `Amount`) VALUES
(6544, 'Lenthren', 'Hambindua', 'Mathematics & Computing Science', 'Male', 'lhambindua', 'lhambindua', 300),
(6799, 'Adelbert', 'Iwik', 'Mathematics & Computing Science', 'Male', 'aiwik', 'aiwik', 300),
(8542, 'Merthon', 'Bahude', 'Mathematics & Computing Science', 'Male', 'mbahude', 'mbahude', 300),
(8706, 'Ryan', 'David', 'Mathematics & Computing Science', 'Male', 'rdavid', 'rdavid', 141.5),
(8841, 'Chris', 'Gadea', 'Mathematics & Computing Science', 'Male', 'cgadea', 'cgadea', 64.88),
(8927, 'Maxie', 'Cletus', 'Mathematics & Computing Science', 'Male', 'mcletus', 'mcletus', 300),
(8096, 'Lyneth', 'Moses', 'Communication Arts', 'Female', 'lmoses', 'lmoses', 300),
(10197, 'Ratu', 'Oki', 'Mathematics & Computing Science', 'Male', 'roki', 'roki', 300),
(1357, 'Chelsea', 'Chow', 'PNG Studies & Internal Relations', 'Female', 'cchow', 'cchow', 300),
(8731, 'Cain', 'Siwick', 'Mathematics & Computing Science', 'Male', 'csiwick', 'csiwick', 300),
(8756, 'Racheal', 'Zial', 'Information Systems', 'Female', 'rzial', 'rzial', 300),
(9942, 'Joanne', 'Sion', 'Finance & Management', 'Female', 'jsion', 'jsion', 300),
(10215, 'Nimson', 'Karu', 'Mathematics & Computing Science', 'Male', 'nkaru', 'nkaru', 240),
(8840, 'Moses', 'Bak', 'Mathematics & Computing Science', 'Male', 'mbak', 'mbak', 210),
(8693, 'Ezra', 'Jambui', 'Mathematics & Computing Science', 'Female', 'ejambui', 'ejambui', 100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `studentinformation`
--
ALTER TABLE `studentinformation`
 ADD PRIMARY KEY (`idNum`), ADD UNIQUE KEY `password` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `studentinformation`
--
ALTER TABLE `studentinformation`
MODIFY `idNum` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10216;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
